const n=["Senin","Selasa","Rabu","Kamis","Jum'at","Sabtu","Minggu"];function t(a){return n[parseInt(a)-1]}export{n as d,t as g};
