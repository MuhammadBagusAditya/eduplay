import{b as i}from"./runtime.Bp4x7A-a.js";function e(t){i(t,t.v+1)}export{e as i};
