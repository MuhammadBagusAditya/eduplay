import{F as s,h as t}from"./runtime.Bp4x7A-a.js";function i(f,n,o){s(()=>{var r=t(()=>n(f,o==null?void 0:o())||{});if(r!=null&&r.destroy)return()=>r.destroy()})}export{i as a};
