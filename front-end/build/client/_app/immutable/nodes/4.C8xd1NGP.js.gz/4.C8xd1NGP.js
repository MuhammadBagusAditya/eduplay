import{L as m}from"../chunks/5.8m0fIDVn.js";export{m as component};
