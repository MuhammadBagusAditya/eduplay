import{l as a}from"../chunks/entry.LQerjGIt.js";export{a as start};
